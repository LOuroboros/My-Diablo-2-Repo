### About

This mod was created by me (Lunos) on March 31, 2023 and it increases the level cap for each character in the game, raising it from Lv99 to Lv250.

To install, simply drag-and-drop the data folder in the game's root folder, and then make a shortcut to the game's executable file containing the parameters "-direct -txt" in the Target field of the file's properties.