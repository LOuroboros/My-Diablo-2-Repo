Giga Inventory Mod for Diablo2-LOD v1.10

This Mod expands the inventory of a character, stash and cube.

It is based on the Extended Stash Mod (from "The Phrozenkeep": www.d2mods.com)
and increases the character inventory to 10x9.

Installation instructions:
1. Make a backup of your chatacters and of the directory "data" (if this
   directory exists).
2. Copy the supplied directory "data" into the Diablo2 directory.
3. Create a link to the Diablo2 executable and add the
   parameters "-direct -txt".
4. Start the game with this link and enjoy the largest Diablo 2 inventory.

WARNING:
Items in the increased part of the inventory will be lost, if the character
is used in a game with the standard inventory size.

Mhoram     (For Diablo2-LOD v1.09)
Ravenswolf (Updated for Diablo2-LOD v1.10)